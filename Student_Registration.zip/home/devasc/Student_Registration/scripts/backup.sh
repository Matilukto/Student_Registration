#!/bin/bash
zip -r ~/Student_Registration.zip ~/Student_Registration
