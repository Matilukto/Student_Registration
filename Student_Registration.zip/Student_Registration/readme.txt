This project is for student registration
